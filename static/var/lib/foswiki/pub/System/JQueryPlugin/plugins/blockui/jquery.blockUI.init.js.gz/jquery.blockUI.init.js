(function($) {
  $.blockUI.defaults.applyPlatformOpacityRules = false;
  $.blockUI.defaults.css = {};
  $.blockUI.defaults.overlayCSS = {};
  $.blockUI.defaults.growlCSS = {};
})(jQuery);
